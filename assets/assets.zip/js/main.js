
$(document).ready(function(){
			/*	$('#dropdown-menu>li').click(function(e){
					$(this).children('#dropdown-submenu').slideToggle('slow');
					$(this).siblings().children('#dropdown-submenu').slideUp('slow');
					
				});*/
			});
		